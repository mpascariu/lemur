## Contact
---

**Development team and maintainers**

**Marius D. PASCARIU** PhD
Allianz Suisse

Prof. **Jose Manuel ABURTO**
London School of Hygiene and Tropical Medicine
University of Oxford

Prof. **Vladimir CANUDAS-ROMO**
Australian National University (ANU)


