# -------------------------------------------------------------- #
# Author: Marius D. PASCARIU
# Last Update: Tue Oct 17 22:36:36 2023
# -------------------------------------------------------------- #

# lemur Package

#' @details
#' To learn more about the package, start with the vignettes:
#' \code{browseVignettes(package = "lemur")}
#'
#' @import shinyBS
#' @import shinyWidgets
#' @import golem
#' @import ggplot2
#' @import data.table
#' @import sf
#' @import shinydashboard
#'
#' @importFrom shiny 
#' actionButton 
#' addResourcePath 
#' bookmarkButton 
#' br
#' column
#' conditionalPanel 
#' div 
#' fluidPage 
#' fluidRow 
#' h3 
#' icon
#' includeMarkdown 
#' navbarPage 
#' observeEvent 
#' reactive
#' selectInput 
#' shinyApp 
#' sliderInput 
#' shinyOptions
#' showNotification
#' getShinyOption
#' tabPanel 
#' tabsetPanel
#' updateSelectInput 
#' updateSliderInput 
#' validateCssUnit
#' 
#' @importFrom DBI dbConnect dbSendQuery dbFetch dbDisconnect
#' @importFrom RPostgres Postgres
#' @importFrom DT dataTableOutput renderDataTable
#' @importFrom shinyjs useShinyjs
#' @importFrom MortalityLaws LifeTable
#' @importFrom glue glue_data
#' @importFrom purrr map
#'
#' @importFrom htmltools
#' tags
#' tagList
#' tagAppendAttributes
#' HTML
#' findDependencies
#' attachDependencies
#'
#' @importFrom tibble
#' column_to_rownames
#' rownames_to_column
#' new_tibble
#' as_tibble
#'
#' @importFrom tidyr
#' pivot_wider
#' pivot_longer
#' replace_na
#'
#' @importFrom dplyr
#' all_of
#' arrange
#' bind_rows
#' bind_cols
#' group_by
#' left_join
#' filter
#' mutate
#' mutate_all
#' rename
#' summarise
#' select
#' ungroup
#' %>%
#'
#' @importFrom plotly
#' ggplotly
#' layout
#' renderPlotly
#' plotlyOutput
#'
#' @import leaflet
#' @importFrom leaflet.extras
#' addFullscreenControl
#' addResetMapButton
#'
#' @name MortalityCauses
#' @docType package
"_PACKAGE"

